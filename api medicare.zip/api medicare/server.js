const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

let usuarios = []; 
let enfermedades = [];

//LOGIN Y REGISTRO
app.post('/registro', (req, res) => {
    const { nombre, correo, pass } = req.body;
    const nuevoUsuario = { idUsuario: usuarios.length + 1, nombre, correo, pass };
    usuarios.push(nuevoUsuario);
    console.log("\n>>> NUEVO USUARIO:", nuevoUsuario);
    res.json({ success: true, usuario: nuevoUsuario });
});

app.post('/login', (req, res) => {
    const { correo, pass } = req.body;
    const user = usuarios.find(u => u.correo === correo && u.pass === pass);
    if (user) return res.json({ success: true, usuario: user });
    res.status(401).json({ success: false });
});

app.post('/usuarios/update', (req, res) => {
    const { id, nombre, correo, pass } = req.body;
    const index = usuarios.findIndex(u => u.idUsuario == id);
    if (index !== -1) {
        usuarios[index] = { idUsuario: parseInt(id), nombre, correo, pass };
        console.log(">>> PERFIL ACTUALIZADO");
        return res.json({ success: true });
    }
    res.status(404).json({ success: false });
});

//ENFERMEDADES

app.post('/enfermedades', (req, res) => {
    const { nombre, fecha, notas, id_usuario, id_local } = req.body;
    
    const nueva = { 
        id: id_local ? parseInt(id_local) : enfermedades.length + 1, 
        nombre, 
        fecha, 
        notas, 
        id_usuario: parseInt(id_usuario) 
    };
    
    const existeIdx = enfermedades.findIndex(e => e.id === nueva.id);
    if (existeIdx !== -1) {
        enfermedades[existeIdx] = nueva;
    } else {
        enfermedades.push(nueva);
    }

    console.log("\n>>> ENFERMEDAD GUARDADA:", nueva);
    res.json({ success: true, dato: nueva });
});

app.get('/enfermedades', (req, res) => {
    res.json(enfermedades);
});

app.post('/enfermedades', (req, res) => {
    const { nombre, fecha, notas, id_usuario, id_local } = req.body;
    
    let idFinal = parseInt(id_local) || (enfermedades.length + 1);

    const nueva = { 
        id: idFinal, 
        nombre, 
        fecha, 
        notas, 
        id_usuario: parseInt(id_usuario) 
    };
    
    const existeIdx = enfermedades.findIndex(e => e.id === nueva.id);
    if (existeIdx !== -1) {
        enfermedades[existeIdx] = nueva;
    } else {
        enfermedades.push(nueva);
    }
    res.json({ success: true, dato: nueva });
});

app.delete('/enfermedades/:id', (req, res) => {
    const { id } = req.params;
    enfermedades = enfermedades.filter(e => e.id != id);
    console.log(`>>> ENFERMEDAD ${id} ELIMINADA`);
    res.json({ success: true });
});

app.listen(3000, () => {
    console.log("SERVIDOR MEDICARE ACTIVO EN PUERTO 3000");
});


